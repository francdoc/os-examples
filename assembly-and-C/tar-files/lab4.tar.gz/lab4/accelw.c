#include "imu.h"

float accel_f(float time)
{
  float accel=time;

  return accel;
}
