#include <stdlib.h>
#include <stdio.h>

extern unsigned int fiba(unsigned int n);
extern unsigned int fibc(unsigned int n);
