#include "hww.h"

int main(void)
{
  // Call ASM hello world
  hwa();

  // Call C hello world
  hwc();

  exit(1);
}
