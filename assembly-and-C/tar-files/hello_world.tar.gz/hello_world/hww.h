#include <stdlib.h>
#include <stdio.h>

extern void hwa(void);
extern void hwc(void);
