#include <stdio.h>
#include <stdlib.h>

void hwc(void)
{
  printf("Hello world in C\n");
}
